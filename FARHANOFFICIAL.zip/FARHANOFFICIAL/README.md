# Multi Brute Force

cookies method with python2 version
![MBF](https://github.com/dz-id/mbf/blob/master/screenshot/mbf.jpg)

## Installation
```
pkg install python2
pip2 install requests bs4
```

## Run script
```
cd mbf
python2 run.py
```

## Contact
[Facebook](https://www.facebook.com/dulahz)
[Telegram](https://t.me/unikers)